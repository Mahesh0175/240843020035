export default function DoctorHome() {
    return (
        <div>
            <h1>This is Doctor home Page</h1>
        </div>
    )
}