export default function AssistantDoctorHome() {
    return (
        <div>
            <h1>This is Assistant Doctor home Page</h1>
        </div>
    )
}