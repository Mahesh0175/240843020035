import { useReducer, useState } from "react"
import { useDispatch } from "react-redux"
import { useNavigate } from "react-router-dom"
import { login } from "./slice"

export default function Login() {

  const init = {
    uname: "",
    password: ""
  }

  const reducer = (state, action) => {
    switch (action.type) {
      case 'update':
        return { ...state, [action.fld]: action.val }
      case 'reset':
        return init
    }
  }

  const [info, dispatch] = useReducer(reducer, init);
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();
  const reduxAction = useDispatch();

  const sendData = (e) => {
    e.preventDefault();
    const reqOptions = {
      method: "POST",
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(info)
    }
    // fetch("http://localhost:8081/login", reqOptions)
    //   .then(resp => {
    //     console.log("Response status:", resp.status);
    //     if (resp.ok)
    //       return resp.text()
    //     else
    //       throw new Error("server error");
    //   })
    //   .then(text => text.length ? JSON.parse(text) : {})

    //   .then(obj => {

    //     if (Object.keys(obj).length === 0) {
    //       setMsg("Wrong username and password")
    //     }
    //     else {
    //       if (obj.status === false) {
    //         alert("request has not been approved")
    //       }
    //       else {
    //         if (obj.role.rid === 1) {
    //           navigate("/admin_home")
    //         }
    //         else if (obj.role.rid === 2) {
    //           navigate("/doctor_home")
    //         }
    //         else if (obj.role.rid === 3) {
    //           navigate("/assistance_doctor_home")
    //         }
    //         else if (obj.role.rid === 4) {
    //           navigate("/receptionist_home")
    //         }
    //         else {
    //           navigate("/patient_home")
    //         }
    //       }
    //     }
    //   })
    //   .catch((error) => alert("server error. Try after sometimes"))
    fetch("http://localhost:8081/login", reqOptions)
      .then(resp => {
        console.log("Response status:", resp.status);
        return resp.text(); // Parse as text first
      })
      .then(text => {
        console.log("Raw response text:", text);
        return text.length ? JSON.parse(text) : {};
      })
      .then(obj => {
        console.log("Parsed response object:", obj);
        if (Object.keys(obj).length === 0) {
          setMsg("Wrong username and password");
        } else {

          reduxAction(login())

          if (obj.role.rid === 3) {
            navigate("/admin_home")
          }
          else if (obj.role.rid === 1) {
            navigate("/doctor_home")
          }
          else if (obj.role.rid === 2) {
            navigate("/assistance_doctor_home")
          }
          else if (obj.role.rid === 4) {
            navigate("/receptionist_home")
          }
          else {
            navigate("/patient_home")
          }
        }
      })
      .catch(error => console.error("Error:", error));

  }

  return (
    <div>
      <h1>Login</h1>
      <form>
        <div className="mb-3">
          <label htmlFor="uid" className="form-label">Enter Username :</label>
          <input type="text" className="form-control" id="uname" name="uname" value={info.uname}
            onChange={(e) => { dispatch({ type: 'update', fld: 'uname', val: e.target.value }) }} />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Enter Password :</label>
          <input type="password" className="form-control" id="password" name="password" value={info.password}
            onChange={(e) => { dispatch({ type: 'update', fld: 'password', val: e.target.value }) }} />
        </div>
        <button type="submit" className="btn btn-primary mb-3" onClick={(e) => { sendData(e) }}>LOGIN</button>
        <button type="reset" className="btn btn-primary mb-3" onClick={() => { dispatch({ type: 'reset' }) }}>CLEAR</button>
      </form>
      <p>{JSON.stringify(info)}</p>
      <p>{msg}</p>
    </div>
  )
}