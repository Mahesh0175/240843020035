export default function PatientHome() {
    return (
        <div>
            <h1>
                This is Patient home Page
            </h1>
        </div>
    )
}