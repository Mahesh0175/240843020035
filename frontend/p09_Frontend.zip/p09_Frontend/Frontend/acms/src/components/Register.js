// import React, { useState } from "react";
// import backgroundImage from '../images/img.jpg'

// const Patient = () => {
//     const [formdata, setformdata] = useState({
//         uid: "",
//         uname: "",
//         password: "",
//         fname: "",
//         lname: "",
//         dob: "",
//         address: "",
//         gender: "",
//     });
//     const [error, setError] = useState({});

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setformdata({ ...formdata, [name]: value });
//     };

//     const validateform = () => {
//         const newerrors = {};
//         //if (!formdata.uid) newerrors.uid = "User ID is required";
//         if (!formdata.uname) newerrors.uname = "Username is required";
//         if (!formdata.password || !/^[A-Za-z0-9*%$_.-]{8,12}$/.test(formdata.password))
//             newerrors.password =
//                 "Password must be 8-12 characters with valid special characters (*%$_.-)";
//         if (!formdata.fname) newerrors.fname = "First name is required";
//         if (!formdata.lname) newerrors.lname = "Last name is required";
//         if (!formdata.dob) newerrors.dob = "Date of birth is required";
//         if (!formdata.address) newerrors.address = "Address is required";
//         if (!formdata.gender) newerrors.gender = "Gender is required";
//         setError(newerrors);
//         return Object.keys(newerrors).length === 0;
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         if (validateform()) {
//             console.log("Form data submitted:", formdata);
//             alert("Registration successful!");
//         }
//     };

//     return (
//         <div
//             style={{
//                 backgroundImage: `url(${backgroundImage})`,
//                 backgroundSize: "cover",
//                 backgroundPosition: "center",
//                 height: "100vh",
//                 display: "flex",
//                 justifyContent: "center",
//                 alignItems: "center",
//                 position: "relative",
//                 color: "#fff",
//             }}
//         >
//             {/* Dark Overlay for Better Text Visibility */}
//             <div
//                 style={{
//                     position: "absolute",
//                     top: 0,
//                     left: 0,
//                     width: "100%",
//                     height: "100%",
//                     backgroundColor: "rgba(0, 0, 0, 0.6)",
//                     zIndex: 1,
//                 }}
//             ></div>

//             {/* Form Container */}
//             <div
//                 style={{
//                     backgroundColor: "rgba(255, 255, 255, 0.9)",
//                     borderRadius: "15px",
//                     padding: "40px 50px",
//                     width: "600px",
//                     zIndex: 2,
//                     boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)",
//                 }}
//             >
//                 <h4
//                     style={{
//                         textAlign: "center",
//                         marginBottom: "30px",
//                         color: "#333",
//                         fontSize: "28px",
//                     }}
//                 >
//                     Registration Form
//                 </h4>

//                 <form onSubmit={handleSubmit}>
//                     <div
//                         style={{
//                             display: "flex",
//                             flexWrap: "wrap",
//                             gap: "20px",
//                             justifyContent: "space-between",
//                         }}
//                     >
//                         {[
//                             //{ key: "uid", label: "User ID", placeholder: "Enter User ID" },
//                             { key: "uname", label: "Username", placeholder: "Enter Username" },
//                             { key: "password", label: "Password", placeholder: "Enter Password" },
//                             { key: "fname", label: "First Name", placeholder: "Enter First Name" },
//                             { key: "lname", label: "Last Name", placeholder: "Enter Last Name" },
//                             { key: "dob", label: "Date of Birth", placeholder: "Enter Date of Birth" },
//                             { key: "gender", label: "Gender", placeholder: "Enter Gender" },
//                             { key: "address", label: "Address", placeholder: "Enter Address" }

//                         ].map(({ key, label, placeholder }) => (
//                             <div
//                                 key={key}
//                                 style={{
//                                     flex: "1 1 calc(50% - 20px)",
//                                     display: "flex",
//                                     flexDirection: "column",
//                                 }}
//                             >
//                                 <label
//                                     style={{
//                                         marginBottom: "5px",
//                                         color: "#333",
//                                         fontSize: "14px",
//                                         fontWeight: "bold",
//                                     }}
//                                 >
//                                     {label}:
//                                 </label>
//                                 <input
//                                     type={
//                                         key === "password"
//                                             ? "password"
//                                             : key === "dob"
//                                                 ? "date"
//                                                 : "text"
//                                     }
//                                     name={key}
//                                     value={formdata[key]}
//                                     placeholder={placeholder}
//                                     onChange={handleChange}
//                                     style={{
//                                         padding: "10px",
//                                         borderRadius: "5px",
//                                         border: "1px solid #ccc",
//                                         fontSize: "14px",
//                                         outline: "none",
//                                     }}
//                                 />
//                                 {error[key] && (
//                                     <p
//                                         style={{
//                                             color: "red",
//                                             fontSize: "12px",
//                                             marginTop: "5px",
//                                         }}
//                                     >
//                                         {error[key]}
//                                     </p>
//                                 )}
//                             </div>
//                         ))}
//                     </div>

//                     <div
//                         style={{
//                             textAlign: "center",
//                             marginTop: "30px",
//                             display: "flex",
//                             gap: "10px",
//                             justifyContent: "center",
//                         }}
//                     >
//                         <button
//                             type="submit"
//                             style={{
//                                 padding: "10px 20px",
//                                 backgroundColor: "#4CAF50",
//                                 color: "white",
//                                 border: "none",
//                                 borderRadius: "5px",
//                                 cursor: "pointer",
//                                 fontSize: "16px",
//                                 fontWeight: "bold",
//                             }}
//                         >
//                             Register
//                         </button>
//                         <button
//                             type="button"
//                             style={{
//                                 padding: "10px 20px",
//                                 backgroundColor: "#3498db",
//                                 color: "white",
//                                 border: "none",
//                                 borderRadius: "5px",
//                                 cursor: "pointer",
//                                 fontSize: "16px",
//                                 fontWeight: "bold",
//                             }}
//                         >
//                             Cancel
//                         </button>
//                     </div>
//                 </form>
//             </div>
//         </div>
//     );
// };

// export default Patient;



import { useReducer, useState } from "react"
import { Navigate } from "react-router-dom"
// import { useDispatch } from "react-redux"
// import { useNavigate } from "react-router-dom"
// import { login } from "./slice"

export default function Register() {

    const init = {
        uname: "",
        password: "",
        fname: "",
        lname: "",
        dob: "",
        address: "",
        gender: "",
    }

    const reducer = (state, action) => {
        switch (action.type) {
            case 'update':
                return { ...state, [action.fld]: action.val }
            case 'reset':
                return init
        }
    }

    const [info, dispatch] = useReducer(reducer, init);
    const [msg, setMsg] = useState("");
    // const navigate = useNavigate();
    // const reduxAction = useDispatch();

    const sendData = (e) => {
        e.preventDefault();
        const reqOptions = {
            method: "POST",
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify(info)
        }
        fetch("http://localhost:8081/register", reqOptions)
            .then(resp => {
                if (resp.ok)
                    return resp.json();
                else
                    throw new Error("Server error");
            })
            .then(obj => {
                alert("Registration successfu. Try Login")
                Navigate('/')
            })
        //.catch((error) => alert("server error. Try later"))

    }

    return (
        <div>
            <h1>Register</h1>
            <form>
                <div className="mb-3">
                    <label htmlFor="uid" className="form-label">Enter Username :</label>
                    <input type="text" className="form-control" id="uname" name="uname" value={info.uname}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'uname', val: e.target.value }) }} />
                </div>
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Enter Password :</label>
                    <input type="password" className="form-control" id="password" name="password" value={info.password}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'password', val: e.target.value }) }} />
                </div>

                <div className="mb-3">
                    <label htmlFor="fname" className="form-label">Enter First Name :</label>
                    <input type="text" className="form-control" id="fname" name="fname" value={info.fname}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'fname', val: e.target.value }) }} />
                </div>


                <div className="mb-3">
                    <label htmlFor="lname" className="form-label">Enter Last Name :</label>
                    <input type="text" className="form-control" id="lname" name="lname" value={info.lname}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'lname', val: e.target.value }) }} />
                </div>

                <div className="mb-3">
                    <label htmlFor="dob" className="form-label">Enter Date of Birth :</label>
                    <input type="date" className="form-control" id="dob" name="dob" value={info.dob}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'dob', val: e.target.value }) }} />
                </div>

                <div className="mb-3">
                    <label htmlFor="address" className="form-label">Enter Address :</label>
                    <input type="text" className="form-control" id="address" name="address" value={info.address}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'address', val: e.target.value }) }} />
                </div>

                <div className="mb-3">
                    <label htmlFor="gender" className="form-label">Enter Gender :</label>
                    <input type="text" className="form-control" id="gender" name="gender" value={info.gender}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'gender', val: e.target.value }) }} />
                </div>

                {/* <div className="mb-3">
                    <label htmlFor="status" className="form-label">Enter status :</label>
                    <input type="text" className="form-control" id="status" name="status" value={info.status}
                        onChange={(e) => { dispatch({ type: 'update', fld: 'status', val: e.target.value }) }} />
                </div> */}

                <button type="submit" className="btn btn-primary mb-3" onClick={(e) => { sendData(e) }}>LOGIN</button>
                <button type="reset" className="btn btn-primary mb-3" onClick={() => { dispatch({ type: 'reset' }) }}>CLEAR</button>
            </form>
            <p>{JSON.stringify(info)}</p>
            <p>{msg}</p>
        </div>

    )
}
