export default function ReceptionistHome() {
    return (
        <div>
            <h1>This is Receptionist Home Page</h1>
        </div>
    )
}